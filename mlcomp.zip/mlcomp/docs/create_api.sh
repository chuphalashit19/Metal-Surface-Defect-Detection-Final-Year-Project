#!/usr/bin/env bash
sphinx-apidoc -o ./_modules ../ -M -f

