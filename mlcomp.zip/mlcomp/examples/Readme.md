- [cifar_simple](cifar_simple/Readme.md) is a example extended of [Catalyst cifar_simple](https://github.com/catalyst-team/catalyst/tree/master/examples/cifar_simple)
- [digit-recognizer](digit-recognizer/Readme.md) Kaggle digit recognizer competition
    
    -download from/upload to Kaggle
    
    -Catalyst multistage
    
    -grid search
    
    -distributed learning
    
    -all pipeline within the single command!
    
- [hierarchical_logging](hierarchical_logging/Readme.md) Hierarchical logging.
- [bash](bash/Readme.md) You can run any bash command.
- [click](click/Readme.md) Click is a Python package for creating beautiful command line interfaces. 
You can debug the code as usual, then run it in MLComp's cluster. 