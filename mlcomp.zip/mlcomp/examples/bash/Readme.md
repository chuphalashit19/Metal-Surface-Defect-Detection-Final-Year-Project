Run

```bash
mlcomp dag examples/bash/config.yml
```

You can run any bash command.