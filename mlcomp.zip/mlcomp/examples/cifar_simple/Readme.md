A minimal extended example of [Catalyst cifar_simple](https://github.com/catalyst-team/catalyst/tree/master/examples/cifar_simple)

Run

```bash
cd examples/cifar_simple
mlcomp dag config.yml
```

Just config.yml is added.

The overhead is minimal.