Run

```bash
mlcomp dag examples/click/config.yml
```

Click is a Python package for creating beautiful command line interfaces. 
You can debug the code as usual, then run it in MLComp's cluster. 