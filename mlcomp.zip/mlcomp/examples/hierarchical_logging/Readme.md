Run

```bash
cd examples/hierarchical_logging
mlcomp dag config.yml
```

Navigate to the tasks panel. Open it and find a new task.

Click it and open Report tab. You should see something like that:

![hierarchical_logging](../../docs/imgs/hierarchical_logging.png)