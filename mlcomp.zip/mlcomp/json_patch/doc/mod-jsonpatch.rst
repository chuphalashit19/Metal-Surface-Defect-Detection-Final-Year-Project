.. mod-jsonpatch:

The ``jsonpatch`` module
========================

.. automodule:: jsonpatch
   :members:
