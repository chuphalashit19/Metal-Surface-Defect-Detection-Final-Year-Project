.. mod-jsonpointer:

The ``jsonpointer`` module
============================

.. automodule:: jsonpointer
   :members:
