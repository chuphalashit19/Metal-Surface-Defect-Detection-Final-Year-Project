from .ring import RingLoss

__all__ = ['RingLoss']
