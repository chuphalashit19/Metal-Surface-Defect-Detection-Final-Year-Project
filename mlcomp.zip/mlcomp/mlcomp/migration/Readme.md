This is a database migration repository.

More information at
http://code.google.com/p/sqlalchemy-migrate/


python manage.py version_control - To create the migration table
python manage.py upgrade - To upgrade DB