import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dag',
  templateUrl: './dag.component.html',
  styleUrls: ['./dag.component.css']
})
export class DagComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
